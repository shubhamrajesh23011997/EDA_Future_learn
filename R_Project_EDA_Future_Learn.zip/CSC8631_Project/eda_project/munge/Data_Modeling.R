

library(dplyr)
library(scales)

#Using the answer from here [Importing several files and indexing them ]
csv_files  <-
  list.files(path = "data" ,
             pattern = '\\.csv',
             full.names = TRUE)
csv_files



#read files into a list
Merge <- lapply(csv_files, read.csv, header = TRUE)
Merge

#Using rbind to combine files
Final_data <- do.call(rbind , Merge)
Final_data

#Summary of final data
summary(Final_data)

#column names
colnames(Final_data)

#head
head(Final_data)


#Removing_NA_records
Final_data <- na.omit(Final_data)

#Deleting records where the Leaving reason is "Prefer not say".
Final_data <-
  Final_data[!(Final_data$leaving_reason == "I prefer not to say"), ]
Final_data


#Making data in readable format
Final_data["leaving_reason"][Final_data["leaving_reason"] == "The course wasnâ€™t what I expected"] <-
  "The course wasn't what I expected"
Final_data["leaving_reason"][Final_data["leaving_reason"] == "I donâ€™t have enough time"] <-
  "I don't have enough time"
Final_data["leaving_reason"][Final_data["leaving_reason"] == "The course wonâ€™t help me reach my goals"] <-
  "The course won't help me reach my goals"

Final_data


#Converting table to data frame and calculating percentage of Leaving_reason variable
Data_reason <- Final_data %>%
  group_by(leaving_reason) %>% # Variable to be transformed
  count() %>%
  ungroup() %>%
  mutate(perc = `n` / sum(`n`)) %>%
  arrange(perc) %>%
  mutate(labels = scales::percent(perc))


#Data Preparation for analyzing the "Leaving Reason" week wise
#Data Preparation for analyzing the "Leaving Reason" for 1st week
Data_1st_LR = Final_data[(Final_data$last_completed_week_number == 1), ]
Data_1st_LR <- table(Data_1st_LR$leaving_reason)
Data_1st_LR = as.data.frame(Data_1st_LR)

#Data Preparation for analyzing the "Leaving Reason" for 2nd week
Data_2nd_LR = Final_data[(Final_data$last_completed_week_number == 2), ]
Data_2nd_LR <- table(Data_2nd_LR$leaving_reason)
Data_2nd_LR = as.data.frame(Data_2nd_LR)

#Data Preparation for analyzing the "Leaving Reason" for 3rd week
Data_3rd_LR = Final_data[(Final_data$last_completed_week_number == 3), ]
Data_3rd_LR <- table(Data_3rd_LR$leaving_reason)
Data_3rd_LR = as.data.frame(Data_3rd_LR)

#Modeling data to analysis when did the most people left the course.
#Calculating count of week number.
Data_when <- table(Final_data$last_completed_week_number)
Data_when

#Converting table to Data frame
Data_when = as.data.frame(Data_when)

#Data Preparation for analyzing the "Last step completed" week-wise
#Data Preparation for analyzing the "Last step completed" for 1st week

Data_LCS <- table(Final_data$last_completed_step)
Data_LCS = as.data.frame(Data_LCS)
