# CSC8631- Exploratory data analysis of the survey for Future Learn's Cyber Security course

## Introduction
Candidates all around the world are becoming more interested in mastering cyber security as a way to further their careers. Because of the increased use of the Internet daily and the unprecedented nature of the times, most universities have opted to make their courses available via online sessions. Because the course is provided entirely online, there may be certain challenges and issues that both students and instructors dealing with the modules may encounter. This report examines a Massive Open Online Course (MOOC) on Cyber Security for late 2017 and 2018 using the CRISP-DM (Cross-Industry Standard Process for Data Mining) methodology and R programming. These courses have traditionally been used in the context of teaching and learning which also have recently gained popularity because of the COVID-19 outbreak. The primary objective of this study is to understand why dropping out in the course has increased by analysing their behaviours as well as the course retention and completion rate. By doing this research, the reason why students drop out of classes would be clear and, as a result, enhance the course process for the interest of students. It is universally acknowledged that different learners use learning content in various ways. Some learners, for example, choose to complete their course work, but others make an effort to learn the most fundamental elements from the lengthy coursework and then abandon the rest. On the other hand, this research could be used to uncover the most common student learning patterns and reasons for dropping out. Future Learn gathered information from students who enrolled in the Cyber Security online course in late 2017 and 2018, with students who dropped out in the middle of the course being required to complete the survey. The course was offered in four different intakes: November, February, June, and September. With the help of visualizations, the focus is to enhance the course plan for future intakes so that students can acquire better quality material and presentation of the entire course work with a lower leaving rate. This report focuses on the reason for leaving, the last step the participant completed before leaving, and the week the student left the course after enrolling. The data of around 400 students were examined for trends and to determine when and why they left. Data Visualization was employed to have a better understanding of the business problem.
 
# About CRISP DM Methodology
CRISP DM abbreviated name for Cross Industry Standard Process for Data Mining (CRISP-DM). The CRISP-DM process is a technique for planning a data mining project in an organised manner and is also well-known for its dependable and well-tested technique. CRISP-DM involves a huge amount of repetition. It's crucial to remember that going through the process without finding a solution isn't always a failure. The data science team learns more about the data and the whole project upon each run through the process. CRISP-DM methodology is divided into six stages as below:


### Business Understanding:

Business Understanding defines that identifying the project objectives and needs from a business standpoint, and then incorporating that knowledge into a data mining problem statement and a preliminary plan to achieve the objectives. The purpose of this stage of the process is to identify key aspects that could have an impact on the project's outcome.

Expected Steps:

* Identify the business Objective
*	Plan project strategy
*	Determine business success criteria for business problem 

### Data Understanding:

The data science team should engage in data exploration at this point to determine what data is already available and how clean it is. Another potential obstacle at this stage is whether the data is reliable for the target variable.

Expected Steps:

* Describe data
* Explore data
*	Verify data quality
*	Data quality report

### Data Preparation:

Data must be evaluated to see if it can be used to train a predictive model at this stage. It is essential to choose which features are most suited to predicting our target variable and which should be excluded from the model. At this stage, data must be examined to see if it can be used to train a predictive model. It's very critical to determine which features are best for forecasting our targeted variable and which should be left out of the equation.

Expected Steps:

* Conversion of data into a tabular format.
* Missing values treatment.
* Conversion of data in proper data type
* Normalizing the data

### Modelling

 In the modelling stage, select the modelling process.  While you may have already chosen a tool during the business understanding stage, you will now choose one modelling technique, such as decision tree, Support Vector Machine, or neural network generation, at this point. If you're using multiple techniques, apply this task for each one separately.

Expected Steps:

* Test design generation
* Model building
* Model Assessment

### Evaluation

Throughout this stage, the model needs to be examined how well the model fulfils the business objectives also try to figure out if there's a business reason why it's not working. If time and budget permit, another alternative is to test the model(s) on test applications in real-world applications. In addition to assessing any other data mining results created, the assessment step entails assessing any other data mining outcomes generated. 

Expected steps:

* Review Model and Process
* Determine next steps

### Deployment

In the deployment step, you'll take the conclusions of your evaluation and devise a rollout strategy. If a generic technique for creating the required model(s) has been determined, it is described here for later deployment. It makes it useful to think about deployment options at the business understanding phase as well because deployment is vital for a successful project.

Expected Steps:

* Plan for monitoring and maintenance.
* Make a final report
* Reviewing project

## Business Objectives covered in this study

- What were the most and least common reasons for students dropping out of the Cyber Security course? Week wise analysis for the most common leaving reason?

- Which week did the most and least participants leave the Cyber Security course? Also, what was the most last common step completed by students before dropping out of the course?


# Steps to Run this project
* Clone this repository or download the zip.
* Open R Studio
* Open this project and navigate to ./reports/Project Report.Rmd
* Click on Knit which will perform all the data munging and data analysis and provide the output in pdf