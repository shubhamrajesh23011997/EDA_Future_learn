library(ProjectTemplate)
library(ggplot2)
library(dplyr)


#The Most and Least common reason to leave the course.
#Pie chart creation
Pie_chart = ggplot(Data_reason, aes(x = "", y = perc, fill = leaving_reason)) +
  geom_col() +  coord_polar(theta = "y") + geom_label(aes(label = labels),
                                                      position = position_stack(vjust = 0.5),
                                                      show.legend = FALSE) + theme_void()

Pie_chart

ggsave(file.path('graphs','Pie_chart_Leaving_reason.png'), width = 20)

#Plotting Bar-plot for Most common Leaving Reason for students that left the course in 1st Week
Leaving_reason_1stweek <-
  ggplot(data = Data_1st_LR, aes(x = reorder(Var1,-Freq), y = Freq)) + geom_bar(stat =
                                                                                  "identity", fill = "Brown") +
  geom_text(aes(label = Freq), vjust = -0.2) +
  xlab("Leave Reason") + ylab("Number of Students") + ggtitle(
    "Bar plot for identifying which was the most common Leaving Reason for students that left the course in 1st Week"
  )
Leaving_reason_1stweek
ggsave(file.path('graphs','bar_plot_leaving_reason_1st.png'), width = 20, height = 10)

#Plotting Bar-plot for Most common Leaving Reason for students that left the course in 2nd Week
Leaving_reason_2ndweek <-
  ggplot(data = Data_2nd_LR, aes(x = reorder(Var1,-Freq), y = Freq)) + geom_bar(stat =
                                                                                  "identity", fill = "orange") +
  geom_text(aes(label = Freq), vjust = -0.2) +
  xlab("Leave Reason") + ylab("Number of Students") + ggtitle(
    "Bar plot for identifying which was the most common Leaving Reason for students that left the course in 2nd Week"
  )
Leaving_reason_2ndweek
ggsave(file.path('graphs','bar_plot_leaving_reason_2nd.png'), width = 20, height = 10)


#Plotting Bar-plot for Most common Leaving Reason for students that left the course in 3rd Week
Leaving_reason_3rdweek <-
  ggplot(data = Data_3rd_LR, aes(x = reorder(Var1,-Freq), y = Freq)) + geom_bar(stat =
                                                                                  "identity", fill = "steelblue") +
  geom_text(aes(label = Freq), vjust = -0.2) +
  xlab("Leave Reason") + ylab("Number of Students") + ggtitle(
    "Bar plot for identifying which was the most common Leaving Reason for students that left the course in 3rd Week"
  )
Leaving_reason_3rdweek
ggsave(file.path('graphs','bar_plot_leaving_reason_3rd.png'), width = 20, height = 10)


#In which week did the most student left the course
#Bar-plot of last_completed_week_number VS Number of Students
Last_completed_week <-
  ggplot(data = Data_when, aes(x = reorder(Var1,-Freq), y = Freq)) + geom_bar(stat =
                                                                                "identity", fill = "blue") +
  geom_text(aes(label = Freq), vjust = -0.2) +
  xlab("Week Number") + ylab("Number of Students") + ggtitle("Bar plot for identifying week number where most people left the course")
Last_completed_week
ggsave(file.path('graphs','Bar-plot_LCW.png'), width = 10)


#Plotting Bar-plot for Most common Last step completed for students that left the course
Last_Step_allweek <-
  ggplot(data = Data_LCS, aes(x = Var1, y = Freq)) + geom_bar(stat =
                                                                  "identity", fill = "black") +
  geom_text(aes(label = Freq), vjust = -0.2) +
  geom_bar(stat = "identity") + xlab("Last step Completed") + ylab("Number of Students") + ggtitle(
    "Bar plot for identifying which was the most common Last step completed for students that left the course"
  )
Last_Step_allweek
ggsave(file.path('graphs','Bar-plot_LCS.png'), width = 20, height = 10)

